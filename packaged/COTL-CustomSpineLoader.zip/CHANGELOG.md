# Changelog

### v0.0.2
- Added Multi-skin support per Spine skeleton

### v0.0.1
- Initial Release