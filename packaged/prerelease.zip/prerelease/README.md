# CultTweaker 2.0 — Pre-Release (Experimental Build)

> ## ⚠️ Read this first
>
> **This is an experimental build.** It mainly focuses on the new map editor and world editor
> tools, and it *will* have rough edges. Bugs in this build **may corrupt or lose save data** —
> both your creations and, in the worst case, your game save. Before you play:
>
> **Back up your game saves** (`.../AppData/LocalLow/Massive Monster/Cult Of The Lamb/saves`),
> ideally by playing on a spare save slot.
>
> **Back up your creations** — these folders inside `BepInEx/plugins/CultTweaker/` hold everything
> the editors make, and copying them somewhere safe takes seconds:
>
> | Folder | What it holds |
> | --- | --- |
> | `CustomNodeBlueprints/` | Every room you build in the map editor (including hub rooms) |
> | `CustomLevelBlueprints/` | Levels and hubs (the records that string rooms together) |
> | `CustomDungeonMaps/` | Dungeon maps built with the Dungeon Builder |
> | `CustomWorldMaps/` | World maps — each map is its own folder of art and config |
> | `CustomShapeProfiles/` | Custom terrain art profiles |
> | `LightingProfiles.json` | Saved lighting presets |
>
> If anything goes wrong, those copies are your way back.

---

## The Worldshaper

**The Worldshaper** is CultTweaker's in-game map editor: press **F4** inside a dungeon room and the
room you are standing in becomes your canvas. Everything is edited live, in the real room, with the
real game systems — what you see in the editor is what plays.

Its tools, on the dock along the left:

- **Select** — pick, move, clone (ctrl+drag) and delete anything placed in the room
- **Shape** — draw the ground itself: spline-based terrain with real collision
- **Structure** — place the game's buildings and props
- **Enemy** — place enemies and set up encounters
- **NPC** — place custom NPCs with their own dialogue trees
- **Podium** — weapon and tarot podiums
- **Trigger** — invisible volumes that run action sequences: move the players, talk, play
  animations and cutscenes, change lighting and music, camera work, screen text, open a world map,
  send the players home
- **Door** — the room's four exits
- **Lighting** — colour grade the room, save and reuse profiles
- **Music** — pick the room's soundtrack from the game's own music events
- **Clear** — sweep the room down to a blank canvas
- **Load Map** — load any saved room over the current one
- **Level** — string rooms into a level: entrance to boss, played back to back
- **Dungeon Builder** — assemble full dungeon runs out of your maps

Useful keys: **F6** hides the editor UI for a clean look at the room (and screenshots), **F5**
resets the room, **Ctrl+S** quicksaves under the current name (it warns before overwriting),
**Ctrl+Z** undoes.

## The Hub Editor

A **hub** is a safe town — no enemies, no weapon — built inside the game's own DLC town, emptied
out for you. Hubs live in the **F7 panel**: *New Hub* opens the Worldshaper on a blank town,
*Edit Hub* reopens a saved one, *Visit Hub* plays it. A hub must contain a trigger carrying the
**Hub spawn point** action — that is where the player arrives — and the editor will refuse to save
without one. Dress up a portal with a trigger holding *Return to base* or *Open world map* and the
hub becomes a place your players pass through.

## The World Editor

The world editor builds **custom overworld maps** in the style of the DLC world map: your own
sprites and spine animations as layers, travel nodes with links, unlock chains, keys and locks —
and each node can lead into a custom dungeon, a level, or a hub. Open it from the F7 panel's
World Maps section; **F6** flips between editing and the play view. Its tools:

- **Layer** — sprite and spine art layers, with drag gizmos for moving, scaling and rotating
- **Node** — travel nodes: icons, visibility, unlock requirements, and what each node enters
- **Link** — draw the connections between nodes
- **World File** — save, load, and map-wide settings

Progress on a world map (completed nodes, opened locks) is tracked per save slot.

## Everything else

The rest of CultTweaker 1.x is still here: player spines and fleece transmog, follower
customization and custom forms, structure overrides, custom enemies, NPCs, items, tarots and
cutscenes. This build changes none of their file formats.

---

## Tell us how it feels

This build is as much about **feel** as about bugs. If any part of the editors is janky — a tool
that fights you, a gizmo that is hard to grab, a workflow that takes five clicks where it should
take one, an arrival that looks wrong — we want to hear about it, even (especially) when nothing
is technically broken. "This felt awkward" is exactly the feedback a pre-release exists to gather.

## Feedback & bug reports

Feedback and bug reporting are strongly encouraged while using this pre-release. When something
breaks, the report is many times more useful with:

- **A video or screenshots** of what happened
- **`BepInEx/LogOutput.log`** from the session where it went wrong (copy it before relaunching —
  the game overwrites it on every start)
- What you were doing when it happened, and roughly what the room / hub / world map contained

Drop it all in the [modding discord](https://discord.gg/MUjww9ndx2). Thank you for testing —
every report makes 2.0 better.
