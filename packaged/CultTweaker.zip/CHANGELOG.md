# Changelog

### v0.0.5
- Add Structure Overrides

### v0.0.3
- Add Custom Follower Color Control

### v0.0.2
- Added Multi-skin support per Spine skeleton

### v0.0.1
- Initial Release