# Changelog

### v1.0.2

- Fix an issue where picking up weapons caused an error

### v1.0.1

- Fleece Cycling for all player skins

### v1.0.0

- Name Changed to CultTweaker
- Support for Woolhaven
- Custom Data Loader - create your own custom stuff!
  - Custom Items
  - Custom Food [WIP]
  - Custom Structure
  - Custom Tarot Cards
  - More to be supported soon!

### v0.0.5

- Add Structure Overrides

### v0.0.3

- Add Custom Follower Color Control

### v0.0.2

- Added Multi-skin support per Spine skeleton

### v0.0.1

- Initial Release
