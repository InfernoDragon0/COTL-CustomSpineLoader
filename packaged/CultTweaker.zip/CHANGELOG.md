# Changelog

### v1.1.1

- Added hide slot for follower skins to hide specific slots
- Removed test code for custom dungeons to prevent errors

### v1.1.0

- Added Custom Dungeons
- Fixed an issue with Custom Structures not loading fully (use new custom structure template)

### v1.0.7 / v1.0.8

- Added Scale setting (1x to 5x) to followers
- Player Spine loader now supports co-op separate spine loading
- Re-added Intro fleece to the fleece transmogs
- Player Spines now load in instantly instead of loading it when entering the base for the first time
  - This allows the custom lamb skins to be used in Intro

### v1.0.6

- Fixed an issue where fleece cycling did not include parts of certain fleeces

### v1.0.5

- Fixed an issue where fleece cycling was going over array bounds
- Fixed an issue where fleece cycling caused a softlock
- Added Custom Player Spine Fleece Cycling support
- Added a toggle to turn on or off fleece cycling (F9)
- Added Custom Follower Form + Variant support
- Added a config to dump follower spine slots

### v1.0.4

- Fixed an issue where red overlays are present on custom player spines

### v1.0.3

- Fix an issue where Fleece Cycling did not override some extra parts of the fleece
- Full Follower Customization Support

### v1.0.2

- Fix an issue where picking up weapons caused an error

### v1.0.1

- Fleece Cycling for all player skins

### v1.0.0

- Name Changed to CultTweaker
- Support for Woolhaven
- Custom Data Loader - create your own custom stuff!
  - Custom Items
  - Custom Food [WIP]
  - Custom Structure
  - Custom Tarot Cards
  - More to be supported soon!

### v0.0.5

- Add Structure Overrides

### v0.0.3

- Add Custom Follower Color Control

### v0.0.2

- Added Multi-skin support per Spine skeleton

### v0.0.1

- Initial Release
